local E = ElvUI[1]
local S = E:GetModule('Skins')
local ECD = ExtraCD
local tex = {}

local function SkinIcon(bar, order)
	--print(tostring(bar) .. tostring(order))
	local f = ECD.bar[order]
	f:SetTemplate('Transparent' , true)

	if not tex[order] then
		--print(tostring(bar) .. tostring(order))
		tex[order] = f:CreateTexture()
		tex[order]:SetTexture(ECD.bar.active[order].icon)
		tex[order]:SetTexCoord(unpack(E.TexCoords))
	end
	tex[order]:ClearAllPoints()
	tex[order]:SetPoint("CENTER", f, "CENTER", 0,0)
	tex[order]:SetHeight(f:GetHeight()-2)
	tex[order]:SetWidth(f:GetWidth()-2)
end

local function SkinIconNew(bar, order)
	local f = ECD.bar[order]
	if not tex[order] then
		--print(tostring(bar) .. tostring(order))
		tex[order] = f:CreateTexture()
		tex[order]:SetTexture(ECD.bar.active[order].icon)
		tex[order]:SetTexCoord(unpack(E.TexCoords))
	end
	tex[order]:ClearAllPoints()
	tex[order]:SetAllPoints(f)
	f:CreateBackdrop()
end

hooksecurefunc(ExtraCD, "CreateIcon", SkinIconNew)
 
